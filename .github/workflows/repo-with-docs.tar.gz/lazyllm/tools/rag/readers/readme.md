Each reader module is borrowd from LLAMA_INDEX, but we have added customized parts, including the entire reader, which is inherited from the Modulebase base class, making all reader modules callable.
