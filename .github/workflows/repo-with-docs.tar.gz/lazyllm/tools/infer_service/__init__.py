from .serve import InferServer

__all__ = [
    'InferServer',
]
