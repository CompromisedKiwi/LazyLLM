from .sense_voice import SenseVoiceDeploy

__all__ = [
    'SenseVoiceDeploy'
]
