requirements = dict(alpacalora='''
accelerate
loralib
peft
transformers
tokenizers
deepspeed
sentence_transformers
''', collie='''
collie-lm
''', llamafactory='''
llamafactory
''', lightllm='''
lightllm
''', vllm='''
vllm
''')
