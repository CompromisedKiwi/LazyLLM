try:
    from .lazyllm_cpp import *  # noqa F403
except ImportError:
    pass
